<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo; // Import BelongsTo


class Organisation extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'user_id',
        'title',
        'abn',
        'instagram',
        'facebook',
        'youtube',
        'tiktok',
        'twitter',
        'organisation_address_type',
        'full_address',
        'processing_status',
        'image', 
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'organisation_address_type' => 'string',
        'processing_status' => 'string',
        'full_address' => 'string',
    ];


     public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }


    // You might define relationships here later, e.g., to Users if an organisation has many users.
    // public function users()
    // {
    //     return $this->hasMany(User::class);
    // }
}

