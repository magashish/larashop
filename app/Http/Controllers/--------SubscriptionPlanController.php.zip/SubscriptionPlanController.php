<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Plan; // Assuming your Plan model is in App\Models
use App\Models\ProductPackage;
use App\Models\UserPackageSubscription;


use App\Models\SubscriptionLog;

use Stripe\Stripe; // For direct Stripe API calls (e.g., refunds)
use Stripe\Refund; // For direct Stripe API calls (e.g., refunds)
use Illuminate\Support\Facades\Log; // For logging errors
use Stripe\Invoice; // Import Stripe Invoice for retrieving latest invoice
use Carbon\Carbon;


class SubscriptionPlanController extends Controller
{



    public function __construct()
    {
        // Set Stripe API key for direct Stripe API calls (e.g., for refunds)
        // Ensure CASHIER_SECRET is set in your .env file
        Stripe::setApiKey(config('cashier.secret'));
    }

    /**
     * Display a listing of the plans.
     *
     * @return \Illuminate\View\View
     */
    // public function index()
    // {
    //     $plans = Plan::get();
    //     return view("plans.plans", compact("plans"));
    // }

    public function index()
    {
        $plans = Plan::get();
        $product_package = ProductPackage::get();
        $currentSubscription = null; 
        if (auth()->check()) {
            $currentSubscription = auth()->user()->subscriptions()->active()->first();
        }
        return view("subscription.plans", compact("plans", "product_package","currentSubscription"));
    }



    /**
     * Show the form for creating a new resource.
     */
    // public function create()
    // {
    //     //
    // }


    public function store(Request $request)
    {
        $request->validate([
            'plan' => 'required|string',
            'token' => 'required|string',
        ]);

        $user = $request->user();
        $plan = Plan::find($request->plan);
        $type = $request->input('type');
        $paymentMethod = $request->input('token');

        try {
            if (is_null($user->stripe_id)) {
                $user->createAsStripeCustomer();
            }
            $user->addPaymentMethod($paymentMethod);

            // Determine if the user has any currently active subscription (Cashier or custom)
            // Get the last inserted active Cashier subscription
            $existingActiveCashierSubscription = $user->subscriptions()
                ->active()
                ->orderByDesc('created_at') // Added to get the last inserted active record
                ->first();

            // Get the last inserted active custom package subscription
            $existingActivePackageSubscription = $user->userPackageSubscriptions()
                ->where('status', 'active')
                ->whereDate('ends_at', '>=', Carbon::now())
                ->orderByDesc('created_at') // Added to get the last inserted active record
                ->first();

            $newSubscriptionStatus = 'active';
            $newSubscriptionStartsAt = Carbon::now();
            $newSubscriptionEndsAt = null;

            if ($existingActiveCashierSubscription || $existingActivePackageSubscription) {
                // This block implements the logic from a previous request:
                // "if last record has status active then active otherwise future"
                // This means if ANY active sub/package exists, new one is 'future'.
                // If NO active sub/package, new one is 'active'.
                // Please reconsider if this is the desired behavior for new purchases if a user has NO active subscriptions.
                $newSubscriptionStatus = 'future';
                $currentEndsAt = null;
                if ($existingActiveCashierSubscription) {
                    $currentEndsAt = $existingActiveCashierSubscription->ends_at; // Cashier's ends_at (can be null for ongoing)
                }
                if ($existingActivePackageSubscription && (!$currentEndsAt || $existingActivePackageSubscription->ends_at->greaterThan($currentEndsAt))) {
                    // If package ends later, use package's end date
                    $currentEndsAt = $existingActivePackageSubscription->ends_at;
                }

                // If an end date is found, the new subscription starts the day after
                if ($currentEndsAt) {
                    $newSubscriptionStartsAt = $currentEndsAt->addDay();
                } else {
                    // If current subscription is ongoing (Cashier with null ends_at),
                    // new one effectively starts now but is marked 'future'.
                    // Actual billing/activation logic will depend on how you manage 'future' status.
                    $newSubscriptionStartsAt = Carbon::now();
                }

                // Calculate ends_at for the future package if applicable
                if ($type === 'package' && $plan->access_duration_weeks) {
                    $newSubscriptionEndsAt = $newSubscriptionStartsAt->copy()->addWeeks($plan->access_duration_weeks);
                }

            } else {
                $newSubscriptionStatus = 'active'; 
                $newSubscriptionStartsAt = Carbon::now(); // Starts right now
                if ($type === 'package' && $plan->access_duration_weeks) {
                    $newSubscriptionEndsAt = Carbon::now()->addWeeks($plan->access_duration_weeks);
                }
            }


            if ($type === 'package') {
               $latestEndingSubscriptionOverall = $user->userPackageSubscriptions()
                   ->whereIn('status', ['active', 'future']) // Consider both active and future packages
                   ->whereDate('ends_at', '>=', Carbon::now()->startOfDay()) // Ensure it's not already ended (or ends today)
                   ->orderByDesc('ends_at') 
                   ->orderByDesc('created_at') 
                   ->first(); 

               $newPackageStartsAt = Carbon::now();
               $newPackageStatus = 'active'; // Default to active for new package

               if ($latestEndingSubscriptionOverall) {
                   $newPackageStartsAt = $latestEndingSubscriptionOverall->ends_at->addDay();
                   $newPackageStatus = 'future'; // Mark as future if it's stacked
                   Log::info("User {$user->id}: Stacking new package '{$plan->name}' to start after existing package ends on {$newPackageStartsAt->format('Y-m-d H:i:s')}. Status: '{$newPackageStatus}'.");
               } else {
                   // No existing future packages, start immediately and mark active.
                   Log::info("User {$user->id}: Activating new package '{$plan->name}' immediately as no active or future packages found. Status: 'active'.");
               }

               $newPackageEndsAt = $newPackageStartsAt->copy()->addWeeks($plan->access_duration_weeks);
               $charge = $user->charge(
                $plan->price, // Price is already in cents in the Plan model as per migrations
                $paymentMethod,
                [
                    'description' => $plan->name . ' Purchase',
                    'return_url' => route('payment.success'), 
                ]
               );

               UserPackageSubscription::create([
                'user_id' => $user->id,
                'plan_id' => $plan->id,
                'type' => $plan->type,
                'purchase_date' => Carbon::now(), 
                'starts_at' => $newPackageStartsAt,
                'ends_at' => $newPackageEndsAt,    
                'status' => $newPackageStatus,      
                'stripe_id' => $charge->id, 
               ]);
               return redirect()->route('subscription.manage')->with('success', 'Package created successfully!');

            } elseif ($type === 'subscription') {

               $activePackages = $user->userPackageSubscriptions()
                   ->whereDate('ends_at', '>=', Carbon::now())
                   ->get();

               // foreach ($activePackages as $package) {
               //     $package->update([
               //         'status' => 'suspended', 
               //     ]);
               // }

               $subscriptionBuilder = $user->newSubscription($plan->slug, $plan->stripe_plan);
               $stripeSubscription = $subscriptionBuilder->create($request->token);
               UserPackageSubscription::create([
                   'user_id' => $user->id,
                   'plan_id' => $plan->id,
                   'type' => $plan->type,
                   'purchase_date' => Carbon::now(),
                   'starts_at' => Carbon::now(),
                   'ends_at' => Carbon::now()->addYears(1),
                   'status' => 'active', // Use Stripe's status
                   'stripe_id' => $stripeSubscription->stripe_id,
               ]);


               return redirect()->route('subscription.manage')->with('success', 'Subscription created successfully!');

            }
        } catch (\Exception $e) {
            Log::error("Subscription/Package Purchase Error for User {$user->id} and Plan {$plan->slug}: " . $e->getMessage(), ['exception' => $e]);
            return redirect()->back()->with('error', 'Purchase failed: ' . $e->getMessage());
        }
    }


    // /**
    //  * Store a newly created resource in storage.
    //  */
    // public function store(Request $request)
    // {
    //     //
    // }

     /**
     * Show the subscription page for a specific plan.
     *
     * @param  \App\Models\Plan  $plan
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\View\View
     */

     public function show(string $id, Request $request)
     {
        // Ensure user is authenticated to create a setup intent
        if (!auth()->check()) {
            return redirect()->route('login')->with('error', 'Please log in to subscribe.');
        }
        

        $plan = Plan::findOrFail($id); 
        $user = auth()->user();

        $isSubscription = false;
        if ($plan->type === 'subscription') {
            $isSubscription = true;
        }


        // NEW: Ensure the user has a Stripe customer ID before proceeding
        // This will create a Stripe customer if one doesn't exist for the user,
        // and populate the 'stripe_id' column on your users table.
        try {
            $user->createOrGetStripeCustomer();
        } catch (\Exception $e) {
            Log::error("Stripe Customer Creation/Retrieval Error: " . $e->getMessage(), ['user_id' => $user->id]);
            return redirect()->back()->with('error', 'Could not prepare payment, please try again.');
        }


        //$intent = $user->createSetupIntent();

        $intent = auth()->user()->createSetupIntent([
            'payment_method_options' => [
                'card' => [
                    'request_three_d_secure' => 'automatic',
                ],
            ],
             //'return_url' => route('payment.success'), // Removed as it causes the error here
        ]);




        $currentSubscription = $user->subscriptions()->active()->first();
        return view("subscription.subscription", compact("plan", "isSubscription", "intent", "currentSubscription"));
    }


       /**
     * Display the user's current subscription status and management options.
     *
     * @return \Illuminate\View\View
     */
       public function managesubscription()
       {
        $user = auth()->user();
       
       // $subscriptions = $user->subscriptions()->active()->get();

        $subscriptions = UserPackageSubscription::where('user_id', $user->id)
        ->where('status', 'active')
        ->orderBy('starts_at', 'desc')
        ->get();

        $refundableSubscriptions = $user->subscriptions()->where(function ($query) {
            $query->where('stripe_status', 'canceled')
                  ->orWhereNotNull('ends_at'); 
              })->get();

        return view('subscription.manage_subscription', compact('user', 'subscriptions', 'refundableSubscriptions'));
    }


    /**
     * Display the swap confirmation page.
     *
     * @param  string  $current_subscription
     * @param  string  $new_plan_slug
     * @return \Illuminate\View\View|\Illuminate\Http\RedirectResponse
     */
    public function confirmswappage(string $current_subscription, string $new_plan_slug)
    {

        $user = auth()->user();
        $currentSubscription = $user->subscription($current_subscription);
        $newPlan = Plan::where('slug', $new_plan_slug)->first();
        if (!$currentSubscription || !$currentSubscription->active() || !$newPlan) {
            return redirect()->route('subscription.manage')->with('error', 'Invalid subscription or plan selected for swap.');
        }

        if ($currentSubscription->name === $newPlan->slug) {
            return redirect()->route('subscription.manage')->with('info', 'You are already subscribed to this plan.');
        }

        $estimatedProratedAmount = null;
        $prorationExplanation = null;

        try {
            // Get the Stripe Subscription object
            $stripeSubscription = $currentSubscription->asStripeSubscription();

            // Simulate the swap to get the upcoming invoice (proration preview)
            $upcomingInvoice = Invoice::upcoming([
                'customer' => $user->stripe_id,
                'subscription' => $stripeSubscription->id,
                'subscription_items' => [
                    [
                        'id' => $stripeSubscription->items->data[0]->id, // ID of the current subscription item
                        'price' => $newPlan->stripe_plan, // New Stripe Price ID
                    ],
                ],
                'subscription_proration_behavior' => 'always_invoice', // To ensure proration is calculated
            ]);

            $estimatedProratedAmount = $upcomingInvoice->total; // Amount in cents
            $prorationExplanation = "Estimated charge: $" . number_format($estimatedProratedAmount / 100, 2) . " " . strtoupper($upcomingInvoice->currency) . ".";

            // Check for line items to provide more detail (e.g., credit vs. charge)
            $creditAmount = 0;
            $chargeAmount = 0;
            foreach ($upcomingInvoice->lines->data as $lineItem) {
                if ($lineItem->amount < 0) {
                    $creditAmount += abs($lineItem->amount);
                } else {
                    $chargeAmount += $lineItem->amount;
                }
            }

            if ($creditAmount > 0 && $chargeAmount > 0) {
                $prorationExplanation .= " (Includes a credit of $" . number_format($creditAmount / 100, 2) . " and a charge of $" . number_format($chargeAmount / 100, 2) . ").";
            } elseif ($creditAmount > 0) {
                $prorationExplanation = "Estimated credit: $" . number_format($creditAmount / 100, 2) . " " . strtoupper($upcomingInvoice->currency) . ".";
            }


        } catch (\Stripe\Exception\ApiErrorException $e) {
            Log::error("Stripe Proration Preview Error: " . $e->getMessage(), ['user_id' => $user->id, 'current_sub_id' => $currentSubscription->stripe_id, 'new_plan_slug' => $newPlan->slug]);
            $prorationExplanation = "Could not estimate proration at this time. Please proceed to confirm, or try again later.";
        } catch (\Exception $e) {
            Log::error("General Proration Preview Error: " . $e->getMessage(), ['user_id' => $user->id, 'current_sub_id' => $currentSubscription->stripe_id, 'new_plan_slug' => $newPlan->slug]);
            $prorationExplanation = "An error occurred while estimating proration. Please proceed to confirm, or try again later.";
        }


        return view('subscription.confirm_swap', compact('currentSubscription', 'newPlan', 'estimatedProratedAmount', 'prorationExplanation'));
    }



    /**
     * Swap the user's current subscription to a new plan.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function swapSubscription(Request $request)
    {
        $user = auth()->user();
        $currentSubscription = $user->subscription($request->current_subscription_name);
        $newPlan = Plan::where('slug', $request->new_plan_slug)->firstOrFail();
        if (!$currentSubscription || !$currentSubscription->active()) {
            return redirect()->back()->with('error', 'You do not have an active subscription to change.');
        }
        if ($currentSubscription->type === $newPlan->slug) {
            return redirect()->back()->with('info', 'You are already subscribed to this plan.');
        }
        try {
            // Store the old plan name for logging before the swap updates the subscription object
            $oldPlanNameForLog = $currentSubscription->type;
            $oldStripePriceIdForLog = $currentSubscription->stripe_price;

            // Perform the swap. Cashier handles prorating automatically.
            $currentSubscription->swap($newPlan->stripe_plan);

            // NEW: Explicitly update the 'name' column in the database to ensure it reflects the new plan's slug.
            // This is a safeguard if Cashier's swap doesn't immediately update the model instance's 'name' property
            // or if the database record needs an explicit refresh.
            $currentSubscription->update(['type' => $newPlan->slug]);


            // Log the subscription swap
            SubscriptionLog::create([
                'user_id' => $user->id,
                'subscription_id' => $currentSubscription->id,
                'event_type' => 'swapped',
                'details' => [
                    'from_plan_name' => $oldPlanNameForLog, // Use the name before the swap
                    'to_plan_name' => $newPlan->name, // Our Plan model's name
                    'new_stripe_price_id' => $newPlan->stripe_plan,
                    'old_stripe_price_id' => $oldStripePriceIdForLog,
                    'stripe_subscription_id' => $currentSubscription->stripe_id,
                    'prorated' => true, // Cashier handles proration by default on swap
                ],
                'performed_by_user_id' => auth()->id(),
            ]);

            return redirect()->route('subscription.manage')->with('success', 'Subscription changed to ' . $newPlan->name . ' successfully!');

        } catch (\Exception $e) {
            Log::error("Stripe Subscription Swap Error: " . $e->getMessage(), ['user_id' => $user->id, 'current_plan' => $request->current_subscription_name, 'new_plan' => $request->new_plan_slug]);
            return redirect()->back()->with('error', 'Failed to change subscription: ' . $e->getMessage());
        }
    }


    /**
     * Cancel the user's active subscription.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
    public function cancelSubscription(Request $request)
    {
        $user = auth()->user();
        $request->validate([
            'subscription_name' => 'required|string', // The slug of the plan, used as subscription name
        ]);
        // Find the specific subscription by name (slug)
        $subscription = $user->subscription($request->subscription_name);

        if (!$subscription || $subscription->onGracePeriod()) {
            return redirect()->back()->with('error', 'No active or resumable subscription found for this plan.');
        }

        // if (!$subscription || $subscription->canceled() || $subscription->onGracePeriod()) {
        //     return redirect()->back()->with('error', 'No active or resumable subscription found for this plan.');
        // }

        try {
            $subscription->cancelNow(); 
            return redirect()->route('subscription.manage')->with('success', 'Subscription cancelled successfully.');
        } catch (\Exception $e) {
            Log::error("Stripe Subscription Cancellation Error: " . $e->getMessage(), ['user_id' => $user->id, 'subscription_name' => $request->subscription_name]);
            return redirect()->back()->with('error', 'Failed to cancel subscription: ' . $e->getMessage());
        }
    }


     /**
     * Resume a cancelled subscription that is still on its grace period.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
     public function resumesubscription(Request $request)
     {
        $user = auth()->user();

        $request->validate([
            'subscription_name' => 'required|string', // The slug of the plan, used as subscription name
        ]);

        // Find the specific subscription by name (slug)
        $subscription = $user->subscription($request->subscription_name);

        if (!$subscription || !$subscription->onGracePeriod()) {
            return redirect()->back()->with('error', 'This subscription cannot be resumed.');
        }

        try {
            $subscription->resume();
            return redirect()->route('subscription.manage')->with('success', 'Subscription resumed successfully!');
        } catch (\Exception $e) {
            Log::error("Stripe Subscription Resume Error: " . $e->getMessage(), ['user_id' => $user->id, 'subscription_name' => $request->subscription_name]);
            return redirect()->back()->with('error', 'Failed to resume subscription: ' . $e->getMessage());
        }
    }



      /**
     * Refund a specific Stripe subscription payment.
     * This is typically an ADMIN function and processes a refund for the latest invoice
     * of a selected subscription.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\RedirectResponse
     */
      public function refundsubscription(Request $request)
      {
        // Implement authorization check here (e.g., Gate::authorize('refund subscriptions');)
        // This method should ideally be in an Admin-specific controller.
        // For simplicity, it's placed here as per request.

        $request->validate([
            'subscription_id' => 'required|string|exists:subscriptions,stripe_id', // Validate it's a valid Stripe subscription ID
            'amount' => 'nullable|numeric|min:0.01', // Amount in currency units (e.g., dollars)
            // CORRECTED: 'reason' validation now uses 'in' rule for allowed Stripe values
            'reason' => 'nullable|string|in:duplicate,fraudulent,requested_by_customer',
        ]);

        $user = auth()->user(); // For admin refunds, you'd typically fetch the user associated with the subscription,
                                // rather than assuming the current authenticated user is the subscriber.
                                // For simplicity here, it assumes current user is the subscriber.

        try {
            // Find the subscription using the Stripe ID from the request and ensure it belongs to the user
            $subscription = $user->subscriptions()->where('stripe_id', $request->subscription_id)->firstOrFail();

            // Retrieve the latest invoice for this subscription from Stripe
            // Filtering by customer_id and subscription_id to ensure correctness
            $invoices = Invoice::all([
                'customer' => $user->stripe_id, // Ensure this matches the customer associated with the subscription
                'limit' => 1,
                'subscription' => $subscription->stripe_id,
                'status' => 'paid', // Only consider paid invoices for refund
            ]);

            if (empty($invoices->data) || !$invoices->data[0]->charge) {
                throw new \Exception("No recent paid charge found for this subscription to refund.");
            }

            $latestChargeId = $invoices->data[0]->charge;

            $options = [];
            if ($request->has('amount')) {
                $options['amount'] = (int) ($request->amount * 100); // Convert to cents for Stripe
            }
            // Only add reason to options if it's provided and valid
            if ($request->has('reason')) {
                $options['reason'] = $request->reason;
            }

            $refund = Refund::create(array_merge([
                'charge' => $latestChargeId,
            ], $options));

            return back()->with('success', 'Refund processed successfully for subscription ' . $subscription->name . '. Refund ID: ' . $refund->id);

        } catch (\Stripe\Exception\ApiErrorException $e) {
            Log::error("Stripe Refund Error: " . $e->getMessage(), ['user_id' => $user->id, 'subscription_id' => $request->subscription_id, 'request_data' => $request->all()]);
            return back()->with('error', 'Stripe API error: ' . $e->getMessage());
        } catch (\Exception $e) {
            Log::error("General Refund Error: " . $e->getMessage(), ['user_id' => $user->id, 'subscription_id' => $request->subscription_id, 'request_data' => $request->all()]);
            return back()->with('error', 'An unexpected error occurred: ' . $e->getMessage());
        }
    }






    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
